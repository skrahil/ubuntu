#!/bin/bash

dir = /home/ubuntu/scripts/*.*
for files in $dir
do
  echo $files
done
