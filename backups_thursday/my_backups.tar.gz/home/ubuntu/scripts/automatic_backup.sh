#@/bin/bash

src=/home/ubuntu/scripts
tgt=/home/ubuntu/backups_thursday

tar -cvf $tgt/my_backups.tar.gz $src

echo backup completed
